"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports

# Constants


from functions import file_statistics
file_handle = open("addresses.txt", "r", encoding="utf-8")

r = file_statistics(file_handle)
print(r)
