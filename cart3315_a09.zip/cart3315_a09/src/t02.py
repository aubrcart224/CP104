"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports

# Constants

from functions import read_integers
file_handle = open("numbers.txt", "r", encoding="utf-8")
ri = read_integers(file_handle)
print(ri)
