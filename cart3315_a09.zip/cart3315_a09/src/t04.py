"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports

# Constants

from functions import line_numbering
fileR = open('wilde.txt', 'r', encoding='utf-8')
fileW = open('wilde_numbered.txt', 'w', encoding='utf-8')
line_numbering(fileR, fileW)
