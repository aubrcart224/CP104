"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import dot_product
# Constants


source1 = [10.0, 3.0, 10.0, 3.0, 1.0]
source2 = [8.0, 2.0, 7.0, 3.0, 6.0]

result = dot_product(source1, source2)
print(result)
