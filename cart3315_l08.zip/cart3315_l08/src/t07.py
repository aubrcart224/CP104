"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import list_categorize
# Constants
# Replace this with your actual generation function
values = list_categorize(10)

negatives, positives, zeroes, evens, odds = list_categorize(values)
print(f"List Categorization: {values}")
print(f"Negatives: {negatives}")
print(f"Positives: {positives}")
print(f"Zeroes: {zeroes}")
print(f"Evens: {evens}")
print(f"Odds: {odds}")
