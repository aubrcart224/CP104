"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import get_weekday_name
# Constants


for day in range(1, 8):
    constant = get_weekday_name(day)
    print(f"{day}: {constant}")
