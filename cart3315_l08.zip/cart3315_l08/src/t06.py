"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import list_stats
# Constants

# Replace this with your actual generation function
values = list_stats(10, 20, -2)

smallest, largest, total, average = list_stats(values)
print(f"List Stats: {values}")
print(f"Smallest: {smallest}")
print(f"Largest: {largest}")
print(f"Total: {total}")
print(f"Average: {average}")
