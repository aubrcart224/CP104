"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
# Imports

# Constants


def list_factors(number):
    """
    -------------------------------------------------------
    Calculates and returns list of factors of a number.
    Use: number = list_factors(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """
    i = 1
    fac = []
    while i < number:

        if number % i == 0:
            fac += [i]
            number /= i
        i += 1

    return fac


def list_positives():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored. Enter 0 to stop entries.
    Use: number_list = list_positives()
    -------------------------------------------------------
    Returns:
        number_list - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    nlist = []
    while True:
        enter = int(input("Enter a positive number: "))
        if enter == 0:
            break
        elif enter > 0:
            nlist += [enter]
    return nlist


def get_indexes(numbers, target_number):
    """
    -------------------------------------------------------
    Finds the indexes of target_number in numbers.
    Use: index_list = get_indexes(numbers, target_number)
    -------------------------------------------------------
    Parameters:
        numbers - list of values (list)
        target_number - value to look for in num_list (*)
    Returns:
        index_list - list of indexes of target_number (list of int)
    -------------------------------------------------------
    """
    output = []
    i = 0
    while i < len(numbers):
        if(numbers[i] == target_number):
            output += [i]
        i += 1
    return output


def list_subtract(minuend, subtrahend):
    """
    -------------------------------------------------------
    Alters the contents of minuend so that it does not contain
    any values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are removed from the first list.
    Use: list_subtract(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to not include in difference (list)
    Returns:
        None
    ------------------------------------------------------
    """
    newlist = []
    for i in minuend:
        same = False
        for j in subtrahend:
            if i == j:
                same = True
                break
            if same == False:
                newlist.append(i)
    return newlist


def verify_sorted(numbers):
    """
    -------------------------------------------------------
    Determines whether a list is sorted.
    Use: in_order, index = verify_sorted(numbers)
    -------------------------------------------------------
    Parameters:
        numbers - a list of numbers (list)
    Returns:
        in_order - True if numbers is sorted, False otherwise (bool)
        index - index of first value not in order,
            -1 if in_order is True (int)
    ------------------------------------------------------
    """
    correct = True
    value = -1
    if len(numbers) == 0:
        correct = True
        value = -1

    for i in range(len(numbers)-1):
        if numbers[i] > numbers[i+1]:
            correct = False
            value = i+1

        else:
            correct = True
            value = -1
        return correct, value
