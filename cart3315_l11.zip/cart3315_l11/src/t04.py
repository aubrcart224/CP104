"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants


from functions import generate_matrix_char, print_matrix_char


def test_generate_and_print_matrix():
    # Test with a sample execution
    rows = 3
    cols = 4
    matrix = generate_matrix_char(rows, cols)

    # Display the generated matrix
    print("Generated Matrix:")
    print_matrix_char(matrix)
