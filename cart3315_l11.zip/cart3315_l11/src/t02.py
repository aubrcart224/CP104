"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants


from functions import generate_matrix_char


def test_generate_matrix_char():
    # Test with a sample execution
    rows = 3
    cols = 4
    matrix = generate_matrix_char(rows, cols)

    # Display the generated matrix
    for row in matrix:
        print(row)
