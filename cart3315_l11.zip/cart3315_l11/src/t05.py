"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants


from functions import words_to_matrix


def test_words_to_matrix():
    # Test with a sample execution
    word_list = ["cat", "dog", "big"]
    matrix = words_to_matrix(word_list)

    # Display the generated matrix
    print("Generated Matrix:")
    for row in matrix:
        print(row)
