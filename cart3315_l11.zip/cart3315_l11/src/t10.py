"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants


from functions import find_word_horizontal


def test_find_word_horizontal():
    # Test with a sample execution
    matrix = [['c', 'a', 't'], ['d', 'o', 'g'], ['b', 'i', 'g']]
    word = "dog"
    rows = find_word_horizontal(matrix, word)

    # Display the result
    print(f"Word '{word}' found in rows: {rows}")
