"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants

from functions import matrix_equal


def test_matrix_equal():
    # Test with a sample execution
    matrix1 = [['c', 'a', 't'], ['d', 'o', 'g'], ['b', 'i', 'g']]
    matrix2 = [['c', 'a', 't'], ['d', 'o', 'g'], ['b', 'i', 'g']]

    equal = matrix_equal(matrix1, matrix2)

    # Display the result
    print(f"Matrices are equal: {equal}")
