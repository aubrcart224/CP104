"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports

# Constants


# t02
def generate_matrix_char(rows, cols):
    """
    -------------------------------------------------------
    Generates a 2D list of random lower case letter ('a' - 'z') values
    Use: matrix = generate_matrix_char(rows, cols)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the generated matrix (int > 0)
        cols - number of columns in the generated matrix (int > 0)
    Returns:
        matrix - a 2D list of random characters (2D list of str)
    -------------------------------------------------------
    """

    # make a list
    matrix = generate_matrix_char(rows, cols)
    return matrix

# t04


def print_matrix_char(matrix):
    """
    -------------------------------------------------------
    Prints the contents of a 2D list of strings in a formatted table.
    Prints row and column headings.
    Use: print_matrix_char(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of strings (2D list)
    Returns:
        None.
    -------------------------------------------------------
    """

    # start with a empty matrix
    if not matrix or not matrix[0]:
        print("Empty matrix")
        return

    # Get the number of rows and columns
    rows = len(matrix)
    cols = len(matrix[0])

    # Print column headings
    print(f'{" ":>3}', end='')
    for col in range(cols):
        print(f'{col:>4}', end='')
    print()

    # Print matrix with row headings
    for row in range(rows):
        print(f'{row:>3}', end='')
        for col in range(cols):
            print(f'{matrix[row][col]:>4}', end='')
        print()
# t05


def words_to_matrix(word_list):
    """
    -------------------------------------------------------
    Generates a 2D list of character values from the given
    list of words. All words must be the same length.
    Use: matrix = words_to_matrix(word_list)
    -------------------------------------------------------
    Parameters:
        word_list - a list containing the words to be placed in
            the matrix (list of string)
    Returns:
        matrix - a 2D list of characters of the given words
         in word_list (2D list of string).
    -------------------------------------------------------
    """

    if not word_list:
        print("Word list is empty")
        return

    # Get the number of rows and columns based on the first word
    #rows = len(word_list)
    cols = len(word_list[0])

    # Check if all words have the same length
    if not all(len(word) == cols for word in word_list):
        print("All words must be the same length")
        return

    # Create the matrix
    matrix = [[word[col] for col in range(cols)] for word in word_list]

    return matrix

# t10


def find_word_horizontal(matrix, word):
    """
    -------------------------------------------------------
    Look for word in each row of the given matrix of characters.
    Returns a list of indexes of all rows that are equal to word.
    Returns an empty list if no row is equal to word.
    Use: rows = find_word_horizontal(matrix, word)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix of characters (2D list of str)
        word - the word to search for (str)
    Returns:
        rows - a list of row indexes (list of int)
    ------------------------------------------------------
    """
    rows = []

    for i, row in enumerate(matrix):
        if ''.join(row) == word:
            rows.append(i)

    return rows

# t15


def matrix_equal(matrix1, matrix2):
    """
    -------------------------------------------------------
    Compares two matrices to see if they are equal - i.e. have the
    same contents in the same locations.
    Use: equal = matrix_equal(matrix1, matrix2)
    -------------------------------------------------------
    Parameters:
        matrix1 - the first matrix (2D list of *)
        matrix2 - the second matrix (2D list of *)
    Returns:
        equal - True if matrix1 and matrix2 are equal,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    if len(matrix1) != len(matrix2):
        return False

    for row1, row2 in zip(matrix1, matrix2):
        if len(row1) != len(row2) or any(x != y for x, y in zip(row1, row2)):
            return False

    return True
