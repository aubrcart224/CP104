"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# get inputs
unit_cost = float(input("Enter cost: "))
quantity = int(input("Enter quantity: "))

# multiply inputs for a total
total = quantity * unit_cost

# round it


R_total = f"{total:.2f}"
R_unitcost = f"{unit_cost:.2f}"


# print final output
print(
    f"Given a cost of {R_unitcost}and a quantity of{quantity} the total is ${R_total}")
