"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# ints
first = 100
second = 34
third = 933


# calculations
total = first + second + third

# outputs
print(f'First: {first:_>6}')
print(f'Second:{second:_>6}')
print(f'Third: {third:_>6}')
print(f'Total: {total:_>6}')
