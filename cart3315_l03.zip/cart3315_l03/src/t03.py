"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# print the quotes all in one line each and one function each using multiple print functions
print('Selected quotes from Mark Twain:')
print('')
print('"Do the right thing. It will gratify some people and astonish the rest."')
print('"All generalizations are false, including this one."')
print('"It is better to keep your mouth closed and let people think you are a fool than to open it and remove all doubt."')
print('')
