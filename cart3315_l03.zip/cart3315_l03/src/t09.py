"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """

# get inputs


sweatband = float(input('Enter sweatband cost: '))
pants = float(input('Enter jacket cost: '))
jacket = float(input('Enter jacket cost: '))
# calculate total

total = pants + sweatband + jacket
print('{:<15} {:<15}'.format('fClothes', f'Cost'))
print('{:<15} {:<15}'.format(f'Sweatband', f'$ {sweatband}'))
print('{:<15} {:<15}'.format(f'Pants', f'$ {pants}'))
print('{:<15} {:<15}'.format(f'Jacket', f'$ {jacket}'))
print('{:<15} {:<15}'.format(f'Total', f'$ {total}'))
