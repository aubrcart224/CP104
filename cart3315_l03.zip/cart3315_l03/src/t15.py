"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# assignment statements
integer = 654321
decimal = 654.32
phrase = "Hello World"

# Outputs
print(f"integer: {integer:d}")
print(f"integer: {integer:.2f}")
print(f"integer: {integer:s}")
print(f"decimal: {decimal:d}")
print(f"decimal: {decimal:.2f}")
print(f"decimal: {decimal:s}")
print(f"phrase: {phrase:.2f}")
print(f"phrase: {phrase:d}")
print(f"phrase: {phrase:s}")
