"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from random import randint
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    number = randint(1, high)

    count = 0
    while True:
        count += 1
        guess = int(input("Enter your guess: "))

        if guess < 1 or guess > high:
            print(f"Please enter a number between 1 and {high}.")
        elif guess < number:
            print("Higher!")
        elif guess > number:
            print("Lower!")
        else:
            print(
                f"Congratulations. You guessed the number {number} in {count} attempts.")
            break

    return count


if __name__ == "__main__":
    high = 100
    count = hi_lo_game(high)
    print(f"Number of guesses: {count}")


def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """

    current_sum = 0
    i = 1

    if target == 0:
        current_sum = 1

    while current_sum < target:
        current_sum += i ** 2
        i += 1

    return current_sum


def num_categories():
    """
    -------------------------------------------------------
    Asks a user to enter a series of numbers, then counts and returns
    how may positives, negatives, and zeroes there are.
    Stop processing values when the user enters -999.
    Use: negatives, zeroes, positives = num_categories()
    -------------------------------------------------------
    Returns:
        negatives - number of negative values (int)
        zeroes - number of zero values (int)
        positives - number of positive values (int)
    ------------------------------------------------------
    """
    negatives = 0
    zeroes = 0
    positives = 0

    while True:
        value = float(input("Enter a value (or -999 to stop): "))

        if value == -999:
            break
        elif value < 0:
            negatives += 1
        elif value == 0:
            zeroes += 1
        else:
            positives += 1

    return negatives, zeroes, positives


def meal_costs():
    """
    -----------------------------------------------------------------------
    Asks a user the costs of breakfast, lunch, and supper for each
    day the user was away. Assumes there is at least one day, and
    after entering data for each day asks the user whether they want
    to enter data for another day. Calculates total costs for meals.

    Returns:
        b_total - total breakfasts cost (float)
        l_total - total lunches cost (float)
        s_total - total suppers cost (float)
        a_total - all meals cost (float)
    --------------------------------------------------------------
    """

    b_total = 0.0
    l_total = 0.0
    s_total = 0.0
    a_total = 0.0

    day = 1

    while True:
        print(f"For Day {day}\n")

        breakfast = float(input("How much was breakfast? $"))
        lunch = float(input("How much was lunch? $"))
        supper = float(input("How much was supper? $"))

        total_cost = breakfast + lunch + supper
        a_total += total_cost
        b_total += breakfast
        l_total += lunch
        s_total += supper

        print(f"Your total for the day was ${total_cost:.2f}\n")
        another_day = input("Were you away another day (Y/N)? ")
        if another_day.strip().lower() != "y":
            break
        day += 1

    return b_total, l_total, s_total, a_total


def get_int(low, high):
    """
    -----------------------------------------------------------------------
    Asks a user for an integer value between low and high, and
    continues asking until an acceptable value is input.

    Parameters:
        low - the lowest acceptable integer (inclusive) (int)
        high - the highest acceptable integer (inclusive) (int > low)
    Returns:
        value - a number between low and high (int)
    -----------------------------------------------------------------------
    """
    while True:
        try:
            value = int(input(f"Enter a value between {low} and {high}: "))

            if low <= value <= high:
                return value
            else:
                print("Value entered is out of the acceptable range.")
        except ValueError:
            print("Invalid input. Please enter an integer.")


if __name__ == "__main__":
    low = 0
    high = 100
    value = get_int(low, high)
    print(value)
