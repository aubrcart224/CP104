"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports

# Constants


# t03 function
def customer_best(fh):
    """
    -------------------------------------------------------
    Find the customer with the largest balance.
    Assumes file is not empty.
    Use: result = customer_best(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        result - the record with the greatest balance (list)
    -------------------------------------------------------
    """

    # Initialize variables to store the information of the customer with the largest balance
    best_customer = None
    # Start with negative infinity as the initial maximum balance
    max_balance = float('-inf')

    # Iterate through each line in the file
    for line in fh:
        # Split the line into a list of values using a comma as the delimiter
        customer_data = line.strip().split(',')

        # Extract balance from the customer data and convert it to a float
        balance = float(customer_data[3])

        # Check if the current customer has a larger balance than the current maximum
        if balance > max_balance:
            max_balance = balance
            best_customer = customer_data

    # Return the information of the customer with the largest balance
    return best_customer

# t05 function


def customer_append(fh, fields):
    """
    Appends a customer record to a comma-delimited sequential file.

    Parameters:
        fh - file to add to (file handle - already open for appending)
        fields - a list of the field data to append to the file (list)
    Returns:
        None
    """
    # Convert numerical fields to strings before writing to the file
    fields = [str(field) for field in fields]

    # Join the fields into a comma-delimited string
    record = ','.join(fields)

    # Append the record to the file
    fh.write(record + '\n')
# t06 function


def number_stats(fh):
    """
    -------------------------------------------------------
    Returns statistics on the numbers in a file.
    Assumes file is not empty.
    Use: smallest, largest, total, average = number_stats(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        smallest - smallest number (int)
        largest - largest number (int)
        total - sum of all the numbers in the file (int)
        average - average of all the numbers (float)
    ------------------------------------------------------
    """

    # Initialize variables for statistics
    # Start with positive infinity as the initial smallest value
    smallest = float('inf')
    # Start with negative infinity as the initial largest value
    largest = float('-inf')
    total = 0
    count = 0

    # Iterate through each line in the file
    for line in fh:
        # Convert the line to a float
        number = float(line.strip())

        # Update statistics
        smallest = min(smallest, number)
        largest = max(largest, number)
        total += number
        count += 1

    # Cast the smallest and largest values to integers
    smallest = int(smallest)
    largest = int(largest)

    # Calculate the average
    if count == 0:
        average = 0  # Avoid division by zero
    else:
        average = total / count

    # Return the statistics
    return smallest, largest, total, average


# t08 function
def append_increment(fh):
    """
    Appends a number to the end of the fh. The number appended
    is the last number in the file plus 1.
    Assumes file is not empty.

    Parameters:
        fh - file to search (file handle - already open for reading/writing)
    Returns:
        num - the number appended to the file (int)
    """
    # Read all lines from the file
    lines = fh.readlines()

    if not lines:
        raise ValueError("File is empty")

    # Get the last line (which contains the last number)
    last_line = lines[-1]

    # Extract the last number and increment it
    last_number = int(last_line.strip())
    new_number = last_number + 1

    # Append the new number to the file
    fh.write(str(new_number) + '\n')

    # Return the appended number
    return new_number


# t12 function
def find_shortest(fh):
    """
    Finds the first word with the shortest length in fh.
    Assumes file is not empty.

    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        word - the first word with the shortest length in fh (str)
    """
    # Read all lines from the file
    lines = fh.readlines()

    if not lines:
        raise ValueError("File is empty")

    # Split the lines into words
    words = [word.strip() for line in lines for word in line.split()]

    # Find the first word with the shortest length
    shortest_word = min(words, key=len)

    return shortest_word


# t14 function
def file_copy_n(fh_1, fh_2, n):
    """
    Copies n records from fh_1 (starting from the beginning of the file) to fh_2.

    Parameters:
        fh_1 - file to search (file handle - already open for reading)
        fh_2 - file to search (file handle - already open for appending)
        n - number of lines to copy from fh_1 to fh_2
    Returns:
        None
    """
    # Read the first n lines from fh_1
    lines_to_copy = [fh_1.readline() for _ in range(n)]

    # Write the lines to fh_2
    fh_2.writelines(lines_to_copy)
