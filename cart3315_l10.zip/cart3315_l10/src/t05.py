"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import customer_append


file_path = 'path/to/customers.txt'  # Replace with the actual path to your file
new_customer_data = ['35612', 'David', 'Brown', 237.56, '2008-10-10']

with open(file_path, 'a') as file_handle:
    customer_append(file_handle, new_customer_data)

print("Data:", new_customer_data)
print("Data appended to file")
