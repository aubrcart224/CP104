"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import append_increment
# Constants

file_path = 'path/to/numbers.txt'  # Replace with the actual path to your file
with open(file_path, 'r+') as file_handle:
    appended_number = append_increment(file_handle)

print(f"{appended_number} is appended")
