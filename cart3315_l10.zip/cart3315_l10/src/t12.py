"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import find_shortest
# Constants


file_path = 'path/to/words.txt'  # Replace with the actual path to your file
with open(file_path, 'r') as file_handle:
    shortest_word = find_shortest(file_handle)

print(f"'{shortest_word}' is the first shortest word")
