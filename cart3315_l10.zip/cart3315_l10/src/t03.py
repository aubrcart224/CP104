"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import customer_best
# Constants

file_path = 'path/to/customers.txt'  # Replace with the actual path to your file
with open(file_path, 'r') as file_handle:
    result = customer_best(file_handle)

print("Find customer with the largest balance:")
print(result)
