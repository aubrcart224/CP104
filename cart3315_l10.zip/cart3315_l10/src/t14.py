"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
# Imports
from functions import file_copy_n
# Constants


# Replace with the actual path to your input file
file_path_1 = 'path/to/words.txt'
# Replace with the desired path for the output file
file_path_2 = 'path/to/new_words.txt'

with open(file_path_1, 'r') as file_handle_1, open(file_path_2, 'a') as file_handle_2:
    n = 5  # Specify the number of lines to copy
    file_copy_n(file_handle_1, file_handle_2, n)

print(f"Copying '{file_path_1}' to '{file_path_2}'")
print(f"Number of lines to copy: {n}")
