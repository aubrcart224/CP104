"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# get inputs
P = float(input("Principal: $ "))
I = float(input("Interest (%): "))
T = int(input("Number of years: "))
N = int(input("Number of times interest compounded per year: "))


# calculate

Balance = P * (1 + (I / 100) / N) ** (N * T)

# output final values
print(f'Balance: ${Balance}')
