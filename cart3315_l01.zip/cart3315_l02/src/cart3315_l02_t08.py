"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """

# get imputs, kg and height


userheight = float(input("Enter your height (m):"))
userkg = float(input("Enter your weight (kg):"))
userbmi = float(input(
    "Enter your upper limit BMI (23 if you are from South East Asia and Southern China, 25 for everyone else):"))

# calualte bmi

BMI = userkg / userheight ** 2
BMIPrime = BMI / userbmi
print("Body Mass Index (kg/m^2) =", BMI)
print("BMI Prime =", BMIPrime)

# output it
