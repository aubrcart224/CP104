"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports


from functions import has_word_chain
hwc = has_word_chain(['camel', 'leopard', 'dog', 'giraffe', 'elephant'])
print(hwc)
