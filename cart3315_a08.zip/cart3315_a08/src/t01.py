"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
# Imports

from functions import add_spaces
a_s = add_spaces('StopAndSmellTheRoses.')
print(a_s)
