"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """
# create a program that converts C to F using F= 9/5c + 32 (note water freezes at 32 deg F)
# display both as ints (no decimals)


# prompt the user until they enter a correct value
while True:

    userinput = input("Temperature (F):")

    try:  # Check if the user's input can be converted to an integer
        userint = int(userinput)
        break  # exit the loop if they entered a true int

    except ValueError:
        print("Invalid Input, Please Enter Whole Number")


F = int(userinput)

# Convert C to F
C = (F-32)*(5/9)

# output proper temp in F
print("Temperature (C):", C)
