"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# get inputs for the amount of big dogs and small dogs groomed
# define the price of each grooming  type
SDprice = 75
BDprice = 50

# get user input
while True:

    doginput = int(input("Number of Small dogs groomed:"))

    try:  # Check if the user's input can be converted to an integer
        userint = int(doginput)
        break  # exit the loop if they entered a true int

    except ValueError:
        print("Invalid Input, Please Enter Whole Number")


SDcount = int(doginput)


while True:

    doginput2 = int(input("Number of Large dogs groomed:"))

    try:  # Check if the user's input can be converted to an integer
        userint = int(doginput2)
        break  # exit the loop if they entered a true int

    except ValueError:
        print("Invalid Input, Please Enter Whole Number")


BDcount = int(doginput2)

# multiply each value resprectivly and then add them together for a total

earnings = (BDcount * BDprice + SDcount * SDprice)
# output said total
print("Total Earned for the day: $", earnings)
