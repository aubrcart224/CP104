"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Get the number of seconds from the user
total_seconds = int(input("Enter the number of seconds: "))


# Calculate days, hours, minutes, and remaining seconds
days = total_seconds // 86400  # 1 day = 24 * 60 * 60 seconds
remaining_seconds = total_seconds % 86400
hours = remaining_seconds // 3600  # 1 hour = 60 * 60 seconds
remaining_seconds %= 3600
minutes = remaining_seconds // 60  # 1 minute = 60 seconds
seconds = remaining_seconds % 60

# Print the result
print(f"{days} days, {hours} hours, {minutes} minutes, {seconds} seconds")
