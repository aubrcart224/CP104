"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# Constants
PI = 3.14

# Input from the user
diameter = float(input("Diameter of container base (cm): "))
height = float(input("Height of container (cm): "))
cost_per_cm2 = float(input("Cost of material ($/cm^2): "))
num_containers = int(input("Number of containers: "))

# Calculate the surface area of one container
radius = diameter / 2
base_area = PI * (radius ** 2)
side_area = 2 * PI * radius * height
total_area = base_area + side_area

# Calculate the cost for one container
container_cost = total_area * cost_per_cm2

# Calculate the total cost for all containers
total_cost = container_cost * num_containers

# Display the results
print(f"The total cost of one container is $ {container_cost:.4f}")
print(f"The total cost of all containers is $ {total_cost:.2f}")
