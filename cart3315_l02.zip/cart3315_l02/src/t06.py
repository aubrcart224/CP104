"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-09-22"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# get inputs , intrest rate, number of years on the morgage, (keep all values in months)

Prince = float(input("Mortgage principal ($):"))
Years = int(input("Number of years: "))
months = float(Years*12)
rate = float(input("Yearly interest rate (%):"))/1200

# use the formula to calc said inputs
Mrate = (Prince*rate*(1+rate)**months)/(((1+rate)**months)-1)

# output costs
print("The monthly payments are: $", Mrate)
