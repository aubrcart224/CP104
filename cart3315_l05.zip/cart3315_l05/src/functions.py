"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
# Imports

# Constants


# task 3

def gym_cost(cost, friends):
    """
    -------------------------------------------------------
    Calculates total cost of a gym membership. A member gets a
    discount according to the number of friends they sign up.
        0 friends: 0% discount
        1 friend: 5% discount
        2 friends: 10% discount
        3 or more friends: 15% discount
    Use: final_cost = gym_cost(cost, friends)
    -------------------------------------------------------
    Parameters:
        cost - a gym membership base cost (float > 0)
        friends - number of friends signed up (int >= 0)
    Returns:
        final_cost - cost of membership after discount (float)
    -------
    """

    if friends == 0:
        discount = 0  # 0 percent discount
    elif friends == 1:
        discount = 0.05  # 5 percent discount
    elif friends == 2:
        discount = 0.10  # 10 percent discount
    else:
        discount = 0.15  # 15 percent discount

    final_cost = cost - (cost * discount)

    return final_cost

# task 5


def is_leap(year):
    """
    -------------------------------------------------------
    Determines if a year is a leap year. Every year that is
    exactly divisible by four is a leap year, except for years
    that are exactly divisible by 100, but these centurial years
    are leap years if they are exactly divisible by 400. For
    example, the years 1700, 1800, and 1900 are not leap years,
    but the years 1600 and 2000 are.
    Use: result = is_leap(year)
    -------------------------------------------------------
    Parameters:
        year - a year (int > 0)
    Returns:
        result - True if year is a leap year,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    if year % 400 == 0 or (year % 100 != 0 and year % 4 == 0):
        return True

    else:
        return False

    # task 7


def get_pay(hourly_rate, hours_worked):
    """
    -------------------------------------------------------
    Calculates an employee's net wage given hours and pay.
    Each employee is paid 1.5 times their regular hourly rate for
    all hours over 40. A tax amount of 3.625 percent of gross salary
    is deducted.
    Use: net_payment = get_pay(hourly_rate, hours_worked)
    -------------------------------------------------------
    Parameters:
        hourly_rate - hourly rate of pay (float)
        hours_worked - total hours worked (float)
    Returns:
        net_payment - description (float)
    ------------------------------------------------------
    """

    if hours_worked <= 40:  # check if they worked 40 hours or less
        gross_pay = hourly_rate * hours_worked  # calculate a pay with no bonus
    else:  # over 40 hours worked
        # calculate the pay for 40 hours then add all extra hours worked with bonus rate
        gross_pay = (hourly_rate * 40) + \
            (hourly_rate * 1.5 * hours_worked - 40)

    tax_percentage = 3.625  # tax rate
    tax_amount = (tax_percentage / 100) * gross_pay  # calculate amount
    tax_amount = gross_pay - tax_amount  # calculate total amount made after tax

    # task 12


def pay_raise(status, years, salary):
    """
    -------------------------------------------------------
    Calculates pay raises for employees. Pay raises are based on:
    status: Full Time ('F)' or Part Time ('P')
    and years of service
    Raises are:
        5% for full time greater than or equal to 10 years service
        1.5% for full time less than 4 years service
        3% for part time greater than 10 years service
        1% for part time less than 4 years service
        2% for all others
    Use: new_salary = pay_raise(status, years, salary)
    -------------------------------------------------------
    Parameters:
        status - employment type (str - 'F' or 'P')
        years - number of years employed (int > 0)
        salary - current salary (float > 0)
    Returns:
        new_salary - employee's new salary (float).
    -------------------------------------------------------
    """
    # Initialize raise_percentage to the default value
    raise_percentage = 2  # Default raise for all others

    # Determine raise percentage based on status and years of service
    if status == 'F':
        if years >= 10:
            raise_percentage = 5  # 5% raise for full-time employees with 10 or more years
        elif years < 4:
            raise_percentage = 1.5  # 1.5% raise for full-time employees with less than 4 years
    elif status == 'P':
        if years >= 10:
            raise_percentage = 3  # 3% raise for part-time employees with 10 or more years
        elif years < 4:
            raise_percentage = 1  # 1% raise for part-time employees with less than 4 years

    # Calculate the new salary
    new_salary = salary + (salary * (raise_percentage / 100))

    return new_salary

    # task 15


def fast_food():
    """
    -------------------------------------------------------
    Food order function.
    Asks user for their order and if they want a combo, and if
    necessary, what is the side order for the combo:
    Prices:
        Burger: $6.00
        Wings: $8.00
        Fries combo: add $1.50
        Salad combo: add $2.00
    Use: price = fast_food()
    -------------------------------------------------------
    Returns:
        price - the price of one meal (float)
    -------------------------------------------------------
    """
    # Define menu item prices
    burger_price = 6.00
    wings_price = 8.00
    fries_combo_price = 1.50
    salad_combo_price = 2.00

    # Ask the user for their order
    print("Welcome to the fast-food restaurant!")
    print("Menu:")
    print("1. Burger - $6.00")
    print("2. Wings - $8.00")

    order_choice = int(
        input("Enter the number of your order (1 for Burger, 2 for Wings): "))

    # Validate the user's input
    if order_choice not in [1, 2]:
        return "Invalid order choice. Please choose 1 for Burger or 2 for Wings."

    # Initialize the total price with the selected item's price
    total_price = burger_price if order_choice == 1 else wings_price

    # Ask if the user wants a combo
    combo_choice = input("Do you want a combo (Y/N)? ").strip().lower()

    if combo_choice == 'y':
        combo_type = input("Choose your combo (1 for Fries, 2 for Salad): ")

        # Validate the combo choice
        if combo_type not in ['1', '2']:
            return "Invalid combo choice. Please choose 1 for Fries or 2 for Salad."

        # Add the combo price to the total
        if combo_type == '1':
            total_price += fries_combo_price
        elif combo_type == '2':
            total_price += salad_combo_price

    return total_price
