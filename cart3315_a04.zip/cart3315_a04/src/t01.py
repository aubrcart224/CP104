"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Aubrey Carter
ID:      169063315
Email:   cart3315@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import day_name
# Constants


dn = day_name(1)
print(dn)
